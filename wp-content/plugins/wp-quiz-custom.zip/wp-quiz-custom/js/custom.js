jQuery(document).ready(function($) {
	$( "#datepicker" ).datepicker({
		inline: true
	});
	$( "#spinner" ).spinner();
});